package com.ejecutar;

import com.base.Trabajador;
import com.base.Padre;
import com.base.Hijo;
import com.base.Hija;

public class Principal {

	public static void main(String[] args) {
		//Padre no se puede instanciar porque es abstract
		//Padre padre1=new Padre();
		//String mensaje=padre.saltar();
		//System.out.println(mensaje);
		
		Trabajador trabajador1=new Trabajador("Pepe","Madrid",1800f,true);
		System.out.println(trabajador1.toString());
		
		Hijo hijo=new Hijo();
		hijo.saludar();
		
		//polimorfismo
		Hijo hijo1=new Hijo();
		Hija hija1=new Hija();
		
		Padre[] familia= {hijo1,hija1};
		familia[1].saludar();
		//polimorfismo basado en herencia
	}
}
