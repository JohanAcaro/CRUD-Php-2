package com.base;

public class Trabajador {
	
	//atributos de clase
	private String nombre;
	private String ciudad;
	private float salarioBruto;
	private boolean contratoTemporal;
	
	//constructor
	public Trabajador(String nombre, String ciudad, float salarioBruto, boolean contratoTemporal) {
		super();
		this.nombre = nombre;
		this.ciudad = ciudad;
		this.salarioBruto = salarioBruto;
		this.contratoTemporal = contratoTemporal;
	}

	//getters / setters
	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getCiudad() {
		return ciudad;
	}


	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}


	public float getSalarioBruto() {
		return salarioBruto;
	}


	public void setSalarioBruto(float salarioBruto) {
		this.salarioBruto = salarioBruto;
	}


	public boolean isContratoTemporal() {
		return contratoTemporal;
	}


	public void setContratoTemporal(boolean contratoTemporal) {
		this.contratoTemporal = contratoTemporal;
	}

	//m�todo gen�rico
	@Override
	public String toString() {
		return "Ficha trabajador 1: [nombre=" + nombre + ", ciudad=" + ciudad + ", salario bruto=" + salarioBruto
				+ ", contrato temporal=" + contratoTemporal + "]";
	}
}
