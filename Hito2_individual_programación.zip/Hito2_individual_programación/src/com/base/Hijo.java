package com.base;

public class Hijo extends Padre {

	private static String nombre;
	private static float numero;

	public Hijo() {
		super(nombre, numero);
	}

	//sobreescritura : m�todo en la clase Hijo que sobreescribe la clase Padre
	public void saludar() {
		System.out.println("Hola, soy el hijo");
	}
}
