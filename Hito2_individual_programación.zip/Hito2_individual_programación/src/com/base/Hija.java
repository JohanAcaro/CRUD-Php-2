package com.base;

public class Hija extends Padre {

	private static String nombre;
	private static float numero;

	public Hija() {
		super(nombre, numero);
	}
	
}
