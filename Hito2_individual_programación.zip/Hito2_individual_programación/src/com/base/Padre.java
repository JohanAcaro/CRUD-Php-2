package com.base;

public class Padre {
	//no se puede crear un objeto Padre
	//una clase abstract NO se puede instanciar, no puedes hacer new
	
	//atributos
	String nombre;
	float numero;
	
	//constructor
	public Padre(String nombre, float numero) {
		super();
		this.nombre = nombre;
		this.numero = numero;
	}

	//m�todo
	public void saludar() {
		System.out.println("Hola, soy el padre");
	}
}
